package Agentes;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class Jogador extends Agent {

   protected void setup() {
       addBehaviour (new CyclicBehaviour(this){
            
           public void action(){
                ACLMessage msg = myAgent.receive();
                if(msg != null){
                    ACLMessage reply = msg.createReply();
                    
                    // Respondendo a Pergunta "Presenca"
                    if(msg.getContent().equalsIgnoreCase("Presenca")){
                        reply.setPerformative(ACLMessage.INFORM);
                        reply.setContent("Presente");
                        myAgent.send(reply);                        
                    }
                    
                } else 
                  block();
            }
           
        });    
    };
}
