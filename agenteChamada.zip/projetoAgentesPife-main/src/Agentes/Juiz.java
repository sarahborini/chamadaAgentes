package Agentes;

import jade.core.*;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Juiz extends Agent {
    
    protected void chamada(String id){
        
        // Pergunta se estão presentes
        addBehaviour (new OneShotBehaviour(this){
            public void action(){
                ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
                msg.addReceiver(new AID(id, AID.ISLOCALNAME));
                msg.setContent("Presenca");
                myAgent.send(msg);                       
            }
        });
        
        // Respostas das presenças
        addBehaviour (new CyclicBehaviour(this){
            public void action(){
                ACLMessage msg = myAgent.receive();
                if(msg != null){
                    if(msg.getContent().equalsIgnoreCase("Presente") && msg.getSender().getLocalName().equals(id)){
                        System.out.println(msg.getSender().getLocalName() + " Presente");
                    }
                } else
                    block();
            }
        }); 
       
    }
    
    protected void validaEnvolvidos(){
        
        chamada("J1");
        chamada("J2");
        chamada("J3");
        chamada("J4");
        chamada("C");
        
    }
        
    protected void setup() {
                     
        validaEnvolvidos();
        
    };
    
}
